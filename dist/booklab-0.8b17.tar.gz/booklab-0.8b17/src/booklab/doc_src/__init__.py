"""
Booklab master static site:

* `doc_src/` markdown source files
* `docs/` generated static site ready to be used as is with any standard HTTP server

Author: Petre Iordanescu (petre.iordanescu@gmail.com)

"""

