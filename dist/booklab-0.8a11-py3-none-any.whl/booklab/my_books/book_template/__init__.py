"""
Contains the book template used when create a new book (`newb` funxtion, `/api/newb/` booklabd route).

Author: Petre Iordanescu (petre.iordanescu@gmail.com)
"""



