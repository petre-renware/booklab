"""
... wip ...
modules to be launched at package call with `-m` option

"""

# this is just a tesr
print("I'm in main module executing what is here...")