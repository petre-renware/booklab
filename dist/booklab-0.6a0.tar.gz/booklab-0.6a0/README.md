# BookLab (p/n: 0000-0163)

Booklab este o aplicatie destinata creari de manuale / documentatii in format electronic de tip "_site static_".

* p/n: `000-0163`
* start date: 2023-Aug-29
* [0.4] release: 2026-Sep-17

Site web dedicat:
- [Ultima versiune stabila](http://booklab.renware.eu)
- [Versiune beta, release candidate, development](bttp://dev.renware.eu/booklab/)


