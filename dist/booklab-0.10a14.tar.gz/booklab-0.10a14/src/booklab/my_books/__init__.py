"""
This component contains all defined books as individual directories, each one with all definions initiated from `book_template/` directory

Author: Petre Iordanescu (petre.iordanescu@gmail.com)
"""



