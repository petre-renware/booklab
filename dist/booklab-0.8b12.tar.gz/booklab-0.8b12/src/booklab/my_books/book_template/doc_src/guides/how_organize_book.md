# Organizarea si configurarea cartii

In aceasta pagina veti gasi o serie de indicatii pentru configurarea si structurarea cartii dvs.

...tbd indicatii generale ...

## Configurarea cartii

...tbd indicatii... 

## Structurarea cartii

...tbd indicatii...





