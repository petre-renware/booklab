
* this directory will keep CGI scripts
executable at server-side by HTTP server
if run with corresponding option:

* a simple and fast python hhtp server: `python -m http.server --cgi`

* for other http servers (Apache HTTP, Nginx, ...) pleaae follow
their documentation ref CGI run configuration

* also please be aware that for unix, Linux, MacOS servers l, all scripts intended to be run must be made executables (`chmod +x`)


