
# start `mkdoks serve`

# #FIXME use mkdocs build with params like explained here `https://www.mkdocs.org/user-guide/cli/#mkdocs-get-deps`

# #TODO for live preview:
#   - the site build is supposed to be already done (`mkdocs build --site-dir ...`)
#   - use `mkdocs serve --no-livereload` to start local HTTP server without monitorig file changes


