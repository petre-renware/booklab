"""**data** component contains the application database as JSON files:

* a books database (`books_catalog.json`) containing all created books and detailed information about each one
* a system database (`app_info.json`) containing information about installed application
"""

