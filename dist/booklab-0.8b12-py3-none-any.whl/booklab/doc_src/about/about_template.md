
# Despre Booklab

{% raw %}

* Versiunea aplicatiei **{{ version }}**
* Autor: Petre Iordanescu (petre.iordanescu@gmail.com)
* Copyright: RENware Software Systems (http://www.renware.eu)
* Licenta: GNU, freeware
* Site versiune stabila: http://booklab.renware.eu/
* Site ultima versiune: http://dev.renware.eu/booklab/

{% endraw %}




