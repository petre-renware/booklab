this directory will keep various book generations for preview and test purposes (normally will not be in git scope)
intention: to be dropped after each book publishing to save space
