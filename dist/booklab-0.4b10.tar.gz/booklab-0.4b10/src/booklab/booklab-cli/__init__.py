"""**booklab_cli** - CLI module
CLI module to assure system operatins as command line.

Architecture; Linux standard (POSIX) CLI
Author; Petre Iordanescu (petre.iordanescu@gmail.com)
Created; Aug.2025
"""

