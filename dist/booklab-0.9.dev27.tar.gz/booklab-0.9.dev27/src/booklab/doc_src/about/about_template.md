
# Despre Booklab

{% raw %}

* Versiunea aplicatiei: **{{ version }}**
* Autor: Petre Iordanescu (petre.iordanescu@gmail.com)
* Copyright: RENware Software Systems (http://www.renware.eu)
* Licenta: GNU, freeware
* [Site versiune stabila: http://booklab.renware.eu/](http://booklab.renware.eu/)
* [Site ultima versiune: http://dev.renware.eu/booklab/](http://dev.renware.eu/booklab/)


## HTTP endpoints

... incoming ...
from command line run `flask --app booklab.booklabd:api_app routes`



{% endraw %}


