
# List of commands @ 251007


## setup
To setup and config B-oklab installed app.


## init
Creates req directory structure in crt directory (aka installarion dir), at least:
    - my_books/
    - conf/
    - dist/ - where book delivery pack (static site) will be stored
    - ...more...


## server run | restart | stop
Obviously...


## pack-book
Creates a ZIP with the book.../docs/ and copy it in ./dist/ dir.
This is equiv with `dlvb` functionality.
 

