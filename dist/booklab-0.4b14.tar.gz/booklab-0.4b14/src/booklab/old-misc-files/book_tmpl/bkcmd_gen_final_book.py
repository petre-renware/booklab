
# run `mkdocs build --site-dir docs/`
# -#FIXME pls check for docs directory name

# #-FIXME use mkdocs build with params like explained here `https://www.mkdocs.org/user-guide/cli/#mkdocs-get-deps`


