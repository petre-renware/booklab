"""**__version__.py** module that contains Booklab aplication version number.

NOTE: this module is imported and made "public" in `booklab._init__.py`

Author: Petre Iordanescu (petre.iordanescu@gmail.com)
"""

__version__ = "0.4b8"


