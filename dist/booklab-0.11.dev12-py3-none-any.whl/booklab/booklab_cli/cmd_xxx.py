"""Command xxx definition.
"""




