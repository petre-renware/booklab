"""
CLI module to assure system operatins as command line.

Architecture; Linux standard (POSIX) CLI

Author; Petre Iordanescu (petre.iordanescu@gmail.com)
"""




