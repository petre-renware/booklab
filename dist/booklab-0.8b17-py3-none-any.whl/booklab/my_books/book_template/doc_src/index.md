# Book template

[TOC]

This is the initial book template, _root index page_. Change this page with your desired content (text, pictures, ...).

**Keep in mind that this the first page of your book and act also as book cover**.

Field `[TOC]` is optional at tour glance. It will inserta "Table of content" in place where is.

Also have in mind that the electronic-site version of the book will have its index as navigation bar on left side, but other electronic forms of book (for example PDF) will not benefit of a navigation bar...







