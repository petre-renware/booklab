
# List of commands - DO NOT FORGET:

## booklab init
Creates req directory structure in crt directory (aka installarion dir), at least:
    - my_books/
    - conf/
    - dist/ - where book delivery pack (static site) will be stored
    - ...more...


## booklab server run | restart | stop
Obviously...


## booklab pack-book
Creates a ZIP with the book.../docs/ and copy it in ./dist/ dir.
This is equiv with `dlvb` functionality.
 

