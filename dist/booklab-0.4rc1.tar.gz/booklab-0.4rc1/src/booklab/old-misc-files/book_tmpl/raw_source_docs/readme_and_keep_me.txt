
this directory will keep all raw documents of book

acest director va contine toate documentele format sursa (brute) ale cartii

- FISIERELE `index.md.txt` si `print_page.md.txt` trebuiesc tinute asa.
- Cind se creaza proiect nou vor fi REDENUMITE la `md` altfel se transforma automat in HTML la construirea insasi BookLab



-#FIXME rename it to `bk_<bk_code>_doc_src` and
update the cfg YML file when generate ... THINK IF ...
