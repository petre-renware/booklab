
this directory will contain the final generated and assembled book

acest director va contine cartea finala asamblata si generata

****** EQUIVALENT of docs/ clasic


-#FIXME rename it to `bk_<bk_code>_docs` and
update the cfg YML file when generate ... THINK IF ...

