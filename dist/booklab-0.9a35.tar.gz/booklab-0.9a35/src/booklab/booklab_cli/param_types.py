"""Define parameters used by CLI app.

Parameters definition as used by
`Typer` framework in parameters definition
and described through `Annotated` class.
"""

from typing_extensions import Annotated



