"""
will print project core paths
"""

from booklab import PROJECT_ROOT
from booklab import PACKAGE_ROOT
from booklab import DATA_ROOT
from booklab import CONF_ROOT
from booklab import MY_BOOKS_ROOT
from booklab import STATIC_SITE_ROOT


def test_project_paths():
    print(f"{PROJECT_ROOT=}")
    print(f"{PACKAGE_ROOT=}")
    print(f"{DATA_ROOT=}")
    print(f"{CONF_ROOT=}")
    # print(f"{}")





