"""
Booklab utility scripts that solve various aspects in installing, configuring and running Booklab system / application.

Author: Petre Iordanescu (petre.iordanescu@gmail.com)
"""



