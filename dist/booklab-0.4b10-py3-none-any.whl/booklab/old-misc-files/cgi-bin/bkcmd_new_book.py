#!pyenv/bin/python3

#=============================================================
# Script to render NEWB page with book data to create
#-----------------------------------------
# Author: Petre Iordanescu, (c) RENware Softwre Sytems
#=============================================================



#TODO plan
#
# 0. this code is subject of (CGI) NEWB command
#     - remark that this file is agnostic of book template and stay in doc_src/
# --------------
# 1. create a new directory for the new book - this will act as a sandbox for all new book
# 2. unzip the template files (zip with `bk_tml/` directory
# 3. change / update the config files (yml, bkcmd...sh, ...}
# 4. depending on how designed, wr some metadata ref never open of new book
#
################

# #-FIXME use mkdocs build with params like explained here `https://www.mkdocs.org/user-guide/cli/#mkdocs-get-deps`


