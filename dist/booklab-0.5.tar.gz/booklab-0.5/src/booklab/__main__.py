"""
... wip ...
modules to be launched at package call with `-m` option

"""

from . import __version__ as sysver

# this is just a tesr
print("I'm in main module executing what is here...")
print(f"System version is: {sysver=}")



